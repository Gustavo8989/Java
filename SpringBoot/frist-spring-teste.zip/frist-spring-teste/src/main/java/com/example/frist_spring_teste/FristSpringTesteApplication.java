package com.example.frist_spring_teste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FristSpringTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FristSpringTesteApplication.class, args);
	}

}
