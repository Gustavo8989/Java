package com.example.frist_spring_teste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FristSpringTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
